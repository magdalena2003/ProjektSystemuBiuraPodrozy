﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace System_biuro_podróży
{
    public class Rezerwacje : Rezerwacja, ICloneable
    {
        public List<Rezerwacja> listaRezerwacji = new List<Rezerwacja>();
        private List<Rezerwacja> rezerwacje = new List<Rezerwacja>();

        public int Count => rezerwacje.Count;

        public void ZarezerwujWycieczke(Klient klient, Wycieczka wycieczka)
        {
            Rezerwacja rezerwacja = new Rezerwacja(klient, wycieczka);
            listaRezerwacji.Add(rezerwacja);

            Console.WriteLine($"Wycieczka {wycieczka.MiejsceDocelowe} została zarezerwowana przez klienta {klient.Imie} {klient.Nazwisko}.");
        }

        public void AnulujRezerwacje(Klient klient, Wycieczka wycieczka)
        {
            Rezerwacja rezerwacjaDoUsuniecia = listaRezerwacji.Find(r => r.Klient == klient && r.Wycieczka == wycieczka);
            if (rezerwacjaDoUsuniecia != null)
            {
                listaRezerwacji.Remove(rezerwacjaDoUsuniecia);
                Console.WriteLine($"Rezerwacja wycieczki {wycieczka.MiejsceDocelowe} dla klienta {klient.Imie} {klient.Nazwisko} została anulowana.");
            }
            else
            {
                Console.WriteLine("Nie znaleziono rezerwacji do anulowania.");
            }
        }

        public void WyswietlRezerwacje()
        {
            Console.WriteLine("Lista rezerwacji:");
            foreach (var rezerwacja in listaRezerwacji)
            {
                Console.WriteLine($"Klient: {rezerwacja.Klient.Imie} {rezerwacja.Klient.Nazwisko}, Wycieczka: {rezerwacja.Wycieczka.MiejsceDocelowe}");
            }

            if (listaRezerwacji.Count == 0)
            {
                Console.WriteLine("Brak rezerwacji.");
            }
        }

        // Implementacja interfejsu ICloneable
        public object Clone()
        {
            Rezerwacje clonedRezerwacje = new Rezerwacje();

            foreach (Rezerwacja rezerwacja in listaRezerwacji)
            {
                clonedRezerwacje.listaRezerwacji.Add((Rezerwacja)rezerwacja.Clone());
            }

            return clonedRezerwacje;
        }
    }
    [Serializable]
    public class Rezerwacja : ICloneable
    {
        public Klient Klient { get; set; }
        public Wycieczka Wycieczka { get; set; }

        public List<Rezerwacja> listaRezerwacji = new List<Rezerwacja>();
        // Metoda do usuwania rezerwacji po ID
        public bool UsunRezerwacjePoNumerzeTelefonu(string numerTelefonu)
        {
            var rezerwacjaDoUsuniecia = listaRezerwacji.FirstOrDefault(r => r.Klient.NumerTelefonu == numerTelefonu);
            if (rezerwacjaDoUsuniecia != null)
            {
                listaRezerwacji.Remove(rezerwacjaDoUsuniecia);
                Console.WriteLine("Rezerwacja została usunięta");
                return true;
            }
            else
            {
                Console.WriteLine("Nie znaleziono rezerwacji o podanym numerze telefonu");
                return false;
            }
        }
        public Rezerwacja() { }

        public Rezerwacja(Klient klient, Wycieczka wycieczka)
        {
            Klient = klient;
            Wycieczka = wycieczka;
        }

        // Implementacja interfejsu ICloneable
        public object Clone()
        {
            return new Rezerwacja
            {
                Klient = (Klient)Klient.Clone(),
                Wycieczka = (Wycieczka)Wycieczka.Clone()
            };
        }
    }
    public class BrakMiejscException : Exception
    {
        public BrakMiejscException()
        {
        }

        public BrakMiejscException(string message)
            : base(message)
        {
        }

        public BrakMiejscException(string message, Exception inner)
            : base(message, inner)
        {
        }

        public interface IZarzadzanieRezerwacjami
        {
            void ZarezerwujWycieczke(Klient klient, string wycieczkaId);
            void AnulujRezerwacje(Klient klient, string wycieczkaId);
            void WyswietlRezerwacje();
        }
    }
}
