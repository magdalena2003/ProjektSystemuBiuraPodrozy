﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace System_biuro_podróży
{
    public class Przewodnik : ICloneable
    {
        public string Id { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string Telefon { get; set; }
        public string Specjalizacja { get; set; }
        public Przewodnik() { }
        public Przewodnik(string id, string imie, string nazwisko, string telefon, string specjalizacja) 
        {
            Id = id;
            Imie = imie;
            Nazwisko = nazwisko;
            Telefon = telefon;
            Specjalizacja = specjalizacja;
        }

        public void AktualizujDanePrzewodnika(string nowyTelefon, string nowaSpecjalizacja)
        {
            Telefon = nowyTelefon;
            Specjalizacja = nowaSpecjalizacja;
        }

        public interface IZarzadzaniePrzewodnikami
        {
            void DodajPrzewodnika(Przewodnik przewodnik);
            Przewodnik ZnajdzPrzewodnika(string id);
            void AktualizujPrzewodnika(string id, string nowyTelefon, string nowaSpecjalizacja);
            void UsunPrzewodnika(string id);
            void WyswietlPrzewodnikow();
        }

        // Implementacja interfejsu ICloneable
        public object Clone()
        {
            return new Przewodnik(Id, Imie, Nazwisko, Telefon, Specjalizacja);
        }
    }
}
