﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System_biuro_podróży;

public class Wycieczka : WycieczkaBase, ICloneable, IComparable<Wycieczka>, IEquatable<Wycieczka>
{
    public int LiczbaMiejsc { get; set; }

    // Konstruktor bezparametrowy potrzebny do serializacji
    public Wycieczka() : base()
    {
    }

    public Wycieczka(string id, string miejsceDocelowe, decimal cena, DateTime dataRozpoczecia, DateTime dataZakonczenia, int liczbaMiejsc)
        : base(id, miejsceDocelowe, cena, dataRozpoczecia, dataZakonczenia, "")
    {
        LiczbaMiejsc = liczbaMiejsc;
    }

    public Wycieczka(string id, string miejsceDocelowe, decimal cena, DateTime dataRozpoczecia, DateTime dataZakonczenia, string program, int liczbaMiejsc)
        : base(id, miejsceDocelowe, cena, dataRozpoczecia, dataZakonczenia, program)
    {
        LiczbaMiejsc = liczbaMiejsc;
    }

    // Implementacja interfejsu ICloneable
    public object Clone()
    {
        return new Wycieczka(Id, MiejsceDocelowe, Cena, DataRozpoczecia, DataZakonczenia, ProgramWycieczki, LiczbaMiejsc);
    }

    // Implementacja interfejsu IComparable do sortowania po cenie
    public int CompareTo(Wycieczka other)
    {
        // Porównujemy obecny obiekt (this) z innym obiektem (other) na podstawie ceny
        return this.Cena.CompareTo(other.Cena);
    }

    // Implementacja interfejsu IEquatable do porównywania dwóch wycieczek
    public bool Equals(Wycieczka other)
    {
        if (other is null)
            return false;

        return this.Id == other.Id &&
               this.MiejsceDocelowe == other.MiejsceDocelowe &&
               this.Cena == other.Cena &&
               this.DataRozpoczecia == other.DataRozpoczecia &&
               this.DataZakonczenia == other.DataZakonczenia &&
               this.ProgramWycieczki == other.ProgramWycieczki &&
               this.LiczbaMiejsc == other.LiczbaMiejsc;
    }
}

