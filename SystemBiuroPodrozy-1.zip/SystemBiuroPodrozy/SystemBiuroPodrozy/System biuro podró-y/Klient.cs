﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

public class Klient : ICloneable
{
    public string Id { get; set; }
    public string Imie { get; set; }
    public string Nazwisko { get; set; }
    public string Email { get; set; }
    public string NumerTelefonu { get; set; }
   

    public Klient(string id, string imie, string nazwisko, string email, string numerTelefonu)
    {
        Id = id;
        Imie = imie;
        Nazwisko = nazwisko;
        Email = email;
        NumerTelefonu = numerTelefonu;
    }
    public void AktualizujDaneKontaktowe(string nowyEmail, string nowyNumerTelefonu)
    {
        Email = nowyEmail;
        NumerTelefonu = nowyNumerTelefonu;
    }
    // Implementację ToString()
    public override string ToString()
    {
        return $"Id: {Id}, Imię: {Imie}, Nazwisko: {Nazwisko}, Email: {Email}, Numer Telefonu: {NumerTelefonu}";
    }
    public interface IZarzadzanieKlientami
    {
        void DodajKlienta(Klient klient);
        Klient ZnajdzKlienta(string id);
        void AktualizujKlienta(string id, string noweImie, string noweNazwisko);
        void UsunKlienta(string id);
        void WyswietlKlientow();
    }

    // Implementacja interfejsu ICloneable
    public object Clone()
    {
        return new Klient(Id, Imie, Nazwisko, Email, NumerTelefonu);
    }
}
