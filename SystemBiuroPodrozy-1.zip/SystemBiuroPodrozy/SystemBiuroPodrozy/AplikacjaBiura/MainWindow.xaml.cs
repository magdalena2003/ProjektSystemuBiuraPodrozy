﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System_biuro_podróży;

namespace AplikacjaBiura
{
    public partial class MainWindow : Window
    {
        private BiuroPodrozy biuroPodrozy;
        public ObservableCollection<Wycieczka> Wycieczki { get; set; }
        public ObservableCollection<Klient> Klienci { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            InitializeBiuroPodrozy();
            WypelnijWycieczki();
            WypelnijKlientow();
            DataContext = this;
        }

        private void InitializeBiuroPodrozy()
        {
            biuroPodrozy = new BiuroPodrozy();
            // Dodaj kod do inicjalizacji danych biura podróży (klientów, wycieczek, przewodników itp.)
        }

        private void WypelnijKlientow()
        {
            Klienci = new ObservableCollection<Klient>
            {
                new Klient("1", "Jan", "Kowalski", "jan.kowalski@example.com", "123456789"),
                new Klient("2", "Anna", "Nowak", "anna.nowak@example.com", "987654321"),
                new Klient("3", "Marek", "Wiśniewski", "marek.wisniewski@example.com", "456789123"),
                new Klient("4", "Maja", "Kowal", "maja.kowal@example.com", "333444222"),
                new Klient("5", "Beata", "Duda", "dudka@example.com", "877766621"),
                new Klient("6", "Kinga", "Bieszcz", "kingabieszc@example.com", "875344555"),
            };
        }


        private void WypelnijWycieczki()
        {
            Wycieczki = new ObservableCollection<Wycieczka>
    {
        new Wycieczka("1", "Paryż", 1200, DataDatePicker.SelectedDate ?? DateTime.Now, DataDatePicker.SelectedDate?.AddDays(7) ?? DateTime.Now.AddDays(7), 10),
        new Wycieczka("2", "Rzym", 1500, DataDatePicker.SelectedDate ?? DateTime.Now, DataDatePicker.SelectedDate?.AddDays(10) ?? DateTime.Now.AddDays(10), 15),
        new Wycieczka("3", "Barcelona", 1800, DataDatePicker.SelectedDate ?? DateTime.Now, DataDatePicker.SelectedDate?.AddDays(5) ?? DateTime.Now.AddDays(5), 8),
        new Wycieczka("4", "Londyn", 2000, DataDatePicker.SelectedDate ?? DateTime.Now, DataDatePicker.SelectedDate?.AddDays(8) ?? DateTime.Now.AddDays(8), 12),
        new Wycieczka("5", "Nowy Jork", 2500, DataDatePicker.SelectedDate ?? DateTime.Now, DataDatePicker.SelectedDate?.AddDays(14) ?? DateTime.Now.AddDays(14), 20),
    };
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (WycieczkiListView.SelectedItem != null && KlienciComboBox.SelectedItem != null && DataDatePicker.SelectedDate != null)
            {
                Wycieczka wybranaWycieczka = (Wycieczka)WycieczkiListView.SelectedItem;
                Klient wybranyKlient = (Klient)KlienciComboBox.SelectedItem;
                DateTime wybranaData = DataDatePicker.SelectedDate.Value;

                RezerwujWycieczke(wybranyKlient, wybranaWycieczka, wybranaData);
            }
            else
            {
                MessageBox.Show("Proszę wybrać wycieczkę, klienta i datę przed dokonaniem rezerwacji.");
            }
        }

        private void RezerwujWycieczke(Klient klient, Wycieczka wycieczka, DateTime wybranaData)
        {
            try
            {
                wycieczka.DataRozpoczecia = wybranaData; // Ustaw datę rozpoczęcia na wybraną datę
                biuroPodrozy.ZarezerwujWycieczke(klient, wycieczka.Id);
                MessageBox.Show($"Zarezerwowano wycieczkę do {wycieczka.MiejsceDocelowe} dla klienta {klient.Imie} {klient.Nazwisko}\nData rozpoczęcia: {wycieczka.DataRozpoczecia.ToShortDateString()}");
            }
            catch (BrakMiejscException ex)
            {
                MessageBox.Show($"Nie udało się zarezerwować wycieczki. {ex.Message}");
            }
        }

        // Usunięcia rezerwacji
        private void BtnUsunRezerwacje_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNumerTelefonu.Text))
            {
                var numerTelefonu = txtNumerTelefonu.Text;
                var klient = Klienci.FirstOrDefault(k => k.NumerTelefonu == numerTelefonu);
                if (klient != null)
                {
                    bool rezultat = biuroPodrozy.UsunRezerwacjePoNumerzeTelefonu(numerTelefonu);
                    if (rezultat)
                    {
                        MessageBox.Show("Rezerwacja została usunięta.");
                    }
                    else
                    {
                        MessageBox.Show("Nie znaleziono rezerwacji o podanym numerze telefonu.");
                    }
                }
                else
                {
                    MessageBox.Show("Nie znaleziono klienta o podanym numerze telefonu.");
                }
            }
            else
            {
                MessageBox.Show("Proszę wprowadzić numer telefonu do usunięcia rezerwacji.");
            }
        }
    }
}
